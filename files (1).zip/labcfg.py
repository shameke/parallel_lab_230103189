"""Общие утилиты. Запуск: python taskX.py <P_phys> <StudentID>
LAB_QUICK=1 -> быстрый дымовой тест (уменьшенные размеры, НЕ для отчёта)."""
import os, sys, time
import multiprocessing as mp
from harness import BenchStats

QUICK = bool(os.environ.get("LAB_QUICK"))
SCALE = 0.01 if QUICK else 1.0
WARM, RUNS = (0, 3) if QUICK else (1, 5)

def get_args():
    pphys = int(sys.argv[1]) if len(sys.argv) > 1 else max(1, mp.cpu_count() // 2)
    sid = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    return pphys, sid

def p_list(plog):
    ps, p = [], 1
    while p <= plog:
        ps.append(p); p *= 2
    if ps[-1] != plog:
        ps.append(plog)
    return ps

def karp_flatt(S, p):
    return (1 / S - 1 / p) / (1 - 1 / p)

def run_workers(target, arglists):
    """Запускает процессы; воркер первым делом делает bar.wait().
    Таймер стартует после барьера -> время spawn/attach не входит в измерение."""
    bar = mp.Barrier(len(arglists) + 1)
    procs = [mp.Process(target=target, args=(bar, *a)) for a in arglists]
    for pr in procs:
        pr.start()
    bar.wait()
    t0 = time.perf_counter_ns()
    for pr in procs:
        pr.join()
    return (time.perf_counter_ns() - t0) / 1e6

def bench_ms(fn):
    """fn() возвращает мс. Формат результата как у harness.BenchStats."""
    for _ in range(WARM):
        fn()
    s = sorted(fn() for _ in range(RUNS))
    return BenchStats(s[0], s[RUNS // 2], s[(3 * RUNS) // 4] - s[RUNS // 4])
